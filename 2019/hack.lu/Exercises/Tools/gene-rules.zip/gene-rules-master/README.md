# Description

Rule repository to feed Gene https://github.com/0xrawsec/gene

Writing your own rules: https://rawsec.lu/doc/gene/1.6/writerules.html

# Warning

Most of the rules here are generic and might not be exactly what you
want so feel free to modify them.
